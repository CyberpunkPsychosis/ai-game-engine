# Sprite Rigger 导出包

- frames/      逐帧合成好的 PNG（已按锚点对齐）
- parts/       原始部件 PNG（如需在 Godot 里用骨骼重新拼装）
- rig.json     图层 / 层级 / 锚点 / 每帧变换数据
- godot_sprite_rig.gd  Godot 导入脚本

## 在 Godot 里用（最简单：逐帧动画）
1. 把整个文件夹拖进 Godot 项目（如 res://art/character/）
2. 场景里加一个 Node2D，挂上 godot_sprite_rig.gd
3. 设置 rig_path = res://art/character/rig.json
4. 运行即可看到 AnimatedSprite2D 动画，节点原点已对齐角色根锚点。

## 进阶（骨骼拼装）
rig.json 里有每个部件的 parent / pivot / 每帧 x,y,rotation，
可据此用 Sprite2D + 层级自行重建可换装/可程序化的角色。
