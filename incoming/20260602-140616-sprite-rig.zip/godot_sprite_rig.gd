extends Node2D
## 由 Sprite Rigger 导出。把本脚本和导出的文件夹一起放进 Godot 项目，
## 在场景里挂一个 Node2D 并设置 rig_path 指向 rig.json，即可自动生成 AnimatedSprite2D 动画。
## 锚点(origin)已对齐：节点原点 = 角色根锚点。

@export var rig_path: String = "res://rig.json"
@export var autoplay: bool = true

func _ready() -> void:
	var f := FileAccess.open(rig_path, FileAccess.READ)
	if f == null:
		push_error("找不到 rig.json: %s" % rig_path)
		return
	var data: Dictionary = JSON.parse_string(f.get_as_text())
	var base := rig_path.get_base_dir()
	var sprite := AnimatedSprite2D.new()
	var frames := SpriteFrames.new()
	frames.add_animation("default")
	frames.set_animation_speed("default", float(data.get("fps", 12)))
	frames.set_animation_loop("default", true)
	for fr in data.get("frames", []):
		var tex_path := "%s/frames/%s" % [base, fr.get("file", "")]
		var tex := load(tex_path)
		if tex:
			frames.add_frame("default", tex)
	sprite.sprite_frames = frames
	sprite.animation = "default"
	add_child(sprite)
	if autoplay:
		sprite.play("default")
